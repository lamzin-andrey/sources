$(document).ready(function(){
//****************Скругление блочных элементов
		$(".header_bottom").corner("10px top");
		$(".header_bottom_labirint").corner("10px top");
		$(".top_menu").corner("7px");
		$(".top_menu_lab").corner("7px");
	//Скругление блока 
		  $(".block_head").corner("7px top");
		  $(".block_footer").corner("7px bottom");
		  $(".module ul").corner("7px");
		  if(!$.browser.msie){
			$(".phone ul").corner("5px");
			$("#view_content").corner("10px bottom");
			$("#head_content").corner("10px top");
			$("#view_content").corner("10px top");
		  }
	//Скругление главного меню
		  $(".sideLeft li:first").corner("keep top 7px");
		  $(".sideLeft li:last").corner("keep bottom 7px");
   //Скругление таблицы
		$('.payment_table caption').corner("7px top");
		$('.payment_table').corner("keep bottom 7px");
		$('.best_specOffers td').corner("keep 10px");//таблица спецпредложений
//Скругление подвала
 $('.footer').corner("bottom 10px");
//*********************************************************

 //Раскраска нечетных строк таблиц
 $(".container tr:even").css("background","#e6f7ff");
 $(".container2 tr:even").css("background","#e6f7ff");
  $("#transport tr:even").css("background","#e6f7ff");
 $(".weather tr:even").css("background","#e6f7ff");
 
 //Быстрый поиск
 $("#fast_search").hide();
 $(".btn-slide").click(function(){
        /*$("#fast_search").slideToggle("slow");*/
        $(this).toggleClass("active");
		return false;
    });
	//=====Кординаты элемента=========
	 function findPosY(obj) {
		 	    var curtop = 0;
		 	    if (obj.offsetParent) {
		 	        while (1) {
		 	            curtop+=obj.offsetTop;
		 	            if (!obj.offsetParent) {
		 	                break;
		 	            }
		 	            obj=obj.offsetParent;
		 	        }
		 	    } else if (obj.y) {
		 	        curtop+=obj.y;
		 	    }
		 	    return curtop;
		 	}

////////////////////////////////////////////////////////////////////////////
//===================модальные окна для блоков=========
	  $('a[name=modal]').click(function(e) {
		    e.preventDefault();
		    var id = $(this).attr('href');
		    coord=parseInt(findPosY(this));
		    H=$(id).height();//Высота элемента
		    W=$(id).width();//Ширина элемента
		    var maskHeight = $(document).height();
		    var maskWidth = $(window).width();
		    var content=$(id).html();
		   
		    $('#mask').css({'width':maskWidth,'height':maskHeight});
		  
		    $('#mask').fadeIn(1000); 
		    $('#mask').fadeTo("slow",0.8); 
			winH = $(window).height();
			winW = $(window).width();
			var top = winH/2-H/2;
			if(top<=0){
				top = 150;
		    }
		   $("#view_content").css('top',  top);
		   $("#view_content").css('left', winW/2-W/2);
		   $("#view_content").css('width', W);
		   $("#body_content").html(content);
		   if(coord>winH){
			   $("#view_content").css('top',  coord-winH/2);
			    coord2=coord-winH/2-H/2;
			  $('html, body').animate({scrollTop:coord2}, 1200);
		   }
		  
		   $(".window").fadeIn(1000);
		   
		  
		   });
		  
		    $('.window .close').click(function (e) {
		e.preventDefault();
		    $('#mask, .window').hide();
		   
		    }); 
		 
		    $('#mask').click(function () {
		    $(this).hide();
		    $('.window').hide();
		    
		   }); 
//============================================
});