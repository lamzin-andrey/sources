function setupCalendars() {
	var fields = ['admin_tour_date_start', 'admin_tour_date_end'], i = 0;
	for (i = 0; i < fields.length; i++) {
		if (!document.getElementById(fields[i])) {
			continue;
		}
		// Popup Calendar
		Calendar.setup(
			{
				dateField: fields[i],
				triggerElement: fields[i] + '_button'
			}
		);
	}
}

Event.observe(window, 'load', function() { setupCalendars() }) 
