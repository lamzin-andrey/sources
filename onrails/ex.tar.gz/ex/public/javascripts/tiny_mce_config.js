function configureTinyMCE() {
	tinymce.execCommand('mceRemoveControl',true,'editor_id');
	tinymce.execCommand('mceAddControl',true,'editor_id');
	tinyMCE.init({
					mode:"textareas", editor_selector : 'tmce',
					theme_advanced_toolbar_location : "top",
					theme : "advanced",
					convert_urls : false,
					relative_urls : false,
					language:'en',
					plugins : "jbimages,emotions,preview,save,paste,fullscreen,style",
					theme_advanced_buttons1:"cut,copy.paste,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,jbimages,image,formatselect,fontselect,fontsizeselect,code,fullscreen,styleprops"
					
				});
	//tinyMCE.get('admin_author_article').onLoad.dispatch();
	console.log( tinyMCE.get('admin_author_article') );
}
configureTinyMCE();
