(
  function () {
	var D = document,
	W = window;
	function $(i) {
		if (i.tagName || D == i) return i;
		return D.getElementById(i);
	}
	function $$(p, c) {
		p = $(p);
		return p.getElementsByTagName(c);
	}
	W.onDomReady = function () {
		var ls = $$(D, "input"), i;
		for (i = 0; i < ls.length; i++) {
			if (ls[i].hasClassName("ajax_sub")) {
				ls[i].onclick = showLoader;
			}
		}
	}
	if (W.attachEvent) {
		W.attachEvent("onload", onDomReady);
	} else {
		W.addEventListener("DOMContentLoaded", onDomReady, false);
	}
	function iframeBody(i) {
		try {
			return $(i)
			 . contentWindow
			 .document
			 . getElementsByTagName("body")[0];
		 } catch(e) {
			 return null;
		 }
	}
	W.tinymceSave = function(i) {
		if ( iframeBody(i + "_ifr") ) {
			$(i).value = iframeBody(i + "_ifr").innerHTML;
		} else {
			alert("Содержимое редактора TinyMCE утеряно, недопил(ил)");
		}
	}
	
	W.appWindow = function(id, s, onclose, clear) {
		var w = W.innerWidth,
		h = W.innerHeight,
		bgId = "popupbg",
		winId = "popup",
		current = "current_wnd_content",
		content = "appWindowPopup",
		tmp,
		winW,
		winH;
		//вызвать appWindowClose
		appWindowClose();
		W.appCloseCallback = onclose;
		if (!$(id)) {
			return;
		}
		if (clear) {
			var ls = $$(id, "input"), i, lt = $$(id, "textarea");
			for (i = 0; i < (ls.length > lt.length ? ls.length : lt.length); i++) {
				if (ls[i] && ls[i].name != "authenticity_token" ) {
					if (ls[i].type != "checkbox" && ls[i].type != "button" && ls[i].type != "submit") {
						 ls[i].value = "";
					 } else {
						 ls[i].checked = false;
					 }
				}
				if (lt[i]) {
					lt[i].value = "";
				}
			}
		}
		with ( $(winId).style ) {
			width = height = '0px';
		}
		$(winId).style = '';
		$(content).style ='';
		if (s) {
			$("popuptitle").innerHTML = s;
		}
		//Для фона и окна  - установить opacity в ноль а видимость в истину
		$(winId).style.opacity = 0;
		$(bgId).removeClassName("hide");
		$(winId).removeClassName("hide");
		 
		//Взять заданный див.
		//Заменить его созданным дивом current_wnd_content
		tmp = D.createElement("div");
		$$(D, "body")[0].appendChild(tmp);
		tmp.id = current;
		swapNodes(id, tmp);
		//Добавить в контент попапа.
		$(id).removeClassName("hide");
		$(content).removeClassName("scrollx");
		$(content).removeClassName("scrolly");
		$(content).appendChild( $(id) );
		//getviewport
		if (!w && _d.documentElement && _d.documentElement.clientWidth) {
			w = _d.documentElement.clientWidth;
		} else if (!w) {
			w = _d.getElementsByTagName('body')[0].clientWidth;
		}
		if (!h && _d.documentElement && _d.documentElement.clientHeight) {
			h = _d.documentElement.clientHeight;
		} else if (!h) {
			h = _d.getElementsByTagName('body')[0].clientHeight;
		}
		//Определить размер
		$(id).opacity = 0;
		
		winW = $(winId).offsetWidth;
		winH = $(winId).offsetHeight;
		//Если меньше чем у вьюпорта, установить размеры окна в авто и отцентрировать
		if (winW < w && winH < h) {
			with ($(winId).style) {
				left = Math.round((w - winW) / 2) + 'px';
				top  = Math.round((h - winH) / 2) + 'px';
			}
		} else {//Иначе установить размеры как у вьюпорта.
			with ($(winId).style) {
				left = '0px';
				top  = '0px';
				width = '100%';
				height = h + 'px';
			}
		}
		if ($(id).offsetWidth > $(content).offsetWidth) {
			$(content).addClassName("scrollx");
			$(content).style.maxWidth = (w - 5) + "px";
		}
		if ($(id).offsetHeight > (h - 35) ) {
			$(content).addClassName("scrolly");
			$(content).style.maxHeight = (h - 40) + "px";
		}
		//Установить opacity в 1
		with ($(bgId).style) {
			width = w + 'px';
			height = h + 'px';
		}
		$(winId).style.opacity = 1;
		$(id).setAttribute("data-srcid", id);
		$(id).id = "execute_block";
	}
	W.swapNodes = function(b1, b2) {
		b1 = $(b1);
		b2 = $(b2);
		var t = D.createElement("i"),
		p1 = b1.parentNode, p2 = b2.parentNode;
		p1.replaceChild(t, b1);
		p2.replaceChild(b1, b2);
		p1.replaceChild(b2, t);
		delete t;
	}
	W.appWindowClose = function() {
		var bgId = "popupbg",
		winId = "popup",
		current = "current_wnd_content",
		execute = "execute_block",
		old = $(execute);
		//сделать невидимыми фон и окно
		$(bgId).removeClassName("hide");
		$(winId).removeClassName("hide");
		$(bgId).addClassName("hide");
		$(winId).addClassName("hide");
		//Если существует на странице див с идентификатором current_wnd_content
		if ($(current)) {
			//взять див с айди execute_block, получить его атрибут srcid, заменить его значением id 
			if (old) {
				old.id = old.getAttribute("data-srcid");
				//и заменить эти дивом current_wnd_content, 
				swapNodes(current, old);
				//не забыв сделать невидимым
				old.addClassName("hide");
			}
			//удалить див current_wnd_content
			$(current).parentNode.removeChild($(current));
		}
		if (W.appCloseCallback instanceof Function) {
			W.appCloseCallback();
		}
	}
	W.appShowAddTourtypeForm = function(actionType, windowTitle) {
		$("form_type").value = actionType;
		$("form_country_id").value = $("admin_tour_country_id").value;
		tinymceSave("admin_tour_description");
		appWindow("tourtypeaddform", windowTitle, restoreAddTour, true);
	}
	W.showLoader = function() {
		var w = W.innerWidth,
			h = W.innerHeight,
			bgId = "loaderbg",
			ldId = "ldrbig";
		//getviewport
		if (!w && _d.documentElement && _d.documentElement.clientWidth) {
			w = _d.documentElement.clientWidth;
		} else if (!w) {
			w = _d.getElementsByTagName('body')[0].clientWidth;
		}
		if (!h && _d.documentElement && _d.documentElement.clientHeight) {
			h = _d.documentElement.clientHeight;
		} else if (!h) {
			h = _d.getElementsByTagName('body')[0].clientHeight;
		}
		$(bgId).removeClassName("hide");
		with ($(bgId).style) {
			width = w + 'px';
			height = h + 'px';
		}
		$(ldId).removeClassName("hide");
		with ($(ldId).style) {
			opacity = 0;
			left = Math.round((w - $(ldId).offsetWidth) / 2) + 'px';
			top  = Math.round((h - $(ldId).offsetHeight) / 2) + 'px';
			opacity = 1;
		}
	}
	W.hideLoader = function() {
		$("ldrbig").addClassName("hide");
		$("loaderbg").addClassName("hide");
	}
	W.restoreAddTour = function () {
		W.appCloseCallback = null;
		appWindow("edit_form_place", "Тур");
		deleteTinyMce("admin_tour_description");
		configureTinyMCE();
	}
	W.deleteTinyMce = function(i, j) {
		j = i + '_parent';
		$(j).parentNode.removeChild($(j));
		$(i).style.display = null;
		$(i).removeAttribute("aria-hidden");
	}
	W.deleteSelected = function() {
		if (!confirm("Вы уверены?")) {
			return;
		}
		var ls = $$(D, "input"), i, re = /all_delete\[[0-9]+\]/, f = D.forms.terminate_all_form, ils = $$(f, "input"),
			input, token, a_token = "authenticity_token";
		for (i = 0; i < ils.length ; i++) {
			if (ils[i].name == a_token) {
				token = ils[i].value;
				break;
			}
		}
		f.innerHTML = '';
		input = D.createElement("input");
		with (input) {
			type = "hidden";
			name = a_token;
			value = token;
		}
		f.appendChild(input);
		
		if ($("country_id")) {
			input = D.createElement("input");
			with (input) {
				type = "hidden";
				name = "id";
				value = $("country_id").value;
			}
			f.appendChild(input);
		}
		
		for (i = 0; i < ls.length; i++) {
			if (re.test(ls[i].name) && ls[i].checked) {
				input = D.createElement("input");
				with (input) {
					type = "hidden";
					className = "recid";
					name = "ids[" + i + "]";
					value = ls[i].name.replace(/\D/g, '');
				}
				f.appendChild(input);
			}
		}
		f.submit();
	}
	W.selectAllRecs = function() {
		var ls = $$(D, "input"), i, re = /all_delete\[[0-9]+\]/;
		for (i = 0; i < ls.length; i++) {
			if (re.test(ls[i].name) ) {
				ls[i].checked = $("delete_all").checked;
			}
		}
	}
	W.loadTourType = function (rowid) {
		$$("tourtypeeditform", "input")[1].value = $$('a-' + rowid, "td")[0].innerHTML;
		$("admin_tourtype_id").value = rowid;
	}
  }
)
()
