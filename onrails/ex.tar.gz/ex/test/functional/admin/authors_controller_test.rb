require 'test_helper'

class Admin::AuthorsControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:admin_authors)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create author" do
    assert_difference('Admin::Author.count') do
      post :create, :author => { }
    end

    assert_redirected_to author_path(assigns(:author))
  end

  test "should show author" do
    get :show, :id => admin_authors(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => admin_authors(:one).to_param
    assert_response :success
  end

  test "should update author" do
    put :update, :id => admin_authors(:one).to_param, :author => { }
    assert_redirected_to author_path(assigns(:author))
  end

  test "should destroy author" do
    assert_difference('Admin::Author.count', -1) do
      delete :destroy, :id => admin_authors(:one).to_param
    end

    assert_redirected_to admin_authors_path
  end
end
