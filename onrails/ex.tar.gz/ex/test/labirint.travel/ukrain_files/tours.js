$(document).ready(function(){
	$("div.tour").hide();
	if(!$.browser.msie){$("div.block_head").corner("7px bottom");}
	$('div.block_head').click(function(){
		status_block=$(this).next('div.tour').css('display');
		if(status_block=="none"){
			$(this).next('div.tour').slideToggle("slow").siblings("div.tour:visible").slideUp("normal");
			$(this).css("background-position","745px -31px").siblings("div.block_head").css("background-position","745px 7px");
			if(!$.browser.msie){$(this).corner("1px bottom").siblings("div.block_head").corner("7px bottom");}
		}
		else{
			$(this).next('div.tour').slideToggle("slow").siblings("div.tour:visible").slideUp("normal");
			$(this).css("background-position","745px 7px").siblings("div.block_head").css("background-position","745px 7px");
			if(!$.browser.msie){$(this).corner("7px bottom").siblings("div.block_head").corner("7px bottom");}
		}
	}); 
});