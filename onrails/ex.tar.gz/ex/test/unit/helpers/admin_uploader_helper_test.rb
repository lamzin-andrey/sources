require 'test_helper'

class AdminUploaderHelperTest < ActionView::TestCase
end
