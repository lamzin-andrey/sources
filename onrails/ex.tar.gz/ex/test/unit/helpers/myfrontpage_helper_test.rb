require 'test_helper'

class MyfrontpageHelperTest < ActionView::TestCase
end
