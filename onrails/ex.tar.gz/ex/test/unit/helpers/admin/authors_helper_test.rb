require 'test_helper'

class Admin::AuthorsHelperTest < ActionView::TestCase
end
