# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = 'ae28938d152d771c5429f847f12240f54e3f25fd3b81b6a475cdd3350580cc004ccb8237047597f94f3383f990ea5ad2ea568084ef270311433efdbe143e9767';
