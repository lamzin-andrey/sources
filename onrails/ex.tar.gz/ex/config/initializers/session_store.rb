# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_ex_session',
  :secret      => 'bd2072747b51dad5b1a2b7ee8c1a8bf365f929b4ff74fb52299ae046f6c8b80fc64e4f63de357b14872009def00a99b6de05a34dba05ebc8917c379c02bd229d'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
