class TestData < ActiveRecord::Migration
  def self.up
    Author.create(:name => %{Александр}, :surname => 'Пушкин', :fathname => 'Сергеевич', :codename => 'pushkin', :url_tail => 'all_books.php')
    Author.create(:name => %{Михаил}, :surname => 'Лермонтов', :fathname => 'Юрьевич', :codename => 'lermontov', :url_tail => 'allbooks.php')
    
    add_column :authors, :article, :text
    add_column :books, :author_id, :integer
    
    Book.create(:title => '', :price => 123.24, :author_id =>1)
    Book.create(:title => '', :price => 2345.58, :author_id =>1)
    Book.create(:title => '', :price => 567.85, :author_id =>1)
    
    Book.create(:title => '', :price => 854.25, :author_id =>2)
    Book.create(:title => '', :price => 489.25, :author_id =>2)
    Book.create(:title => '', :price => 3257.25, :author_id =>2)
  end

  def self.down
    remove_column :authors, :article
    remove_column :books, :text
    Book.delete_all
    Author.delete_all
  end
end
