class ConstraintsTours < ActiveRecord::Migration
  def self.up
    execute "ALTER TABLE tours ADD CONSTRAINT fk_tours_tourtypes FOREIGN KEY (tourtype_id) REFERENCES tourtypes(id)"
    execute "ALTER TABLE tours ADD CONSTRAINT fk_tours_countries FOREIGN KEY (country_id) REFERENCES countries(id)"
  end

  def self.down
    execute "ALTER TABLE tours DROP FOREIGN KEY fk_tours_tourtypes"
    execute "ALTER TABLE tours DROP FOREIGN KEY fk_tours_countries"
  end
end
