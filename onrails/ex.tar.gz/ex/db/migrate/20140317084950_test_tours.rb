class TestTours < ActiveRecord::Migration
  def self.up
    Country.create :country_name => 'Россия', :url_tail => 'all_tours.php', :country_code => 'ru', :page_title => 'Туры в России', :article => '' 
    Country.create :country_name => 'Украина', :url_tail => 'tours.php', :country_code => 'ua', :page_title => 'Туры по Украине', :article => '' 
    Country.create :country_name => 'Дания', :url_tail => 'excursion.php', :country_code => 'dk', :page_title => 'Туры по Дании', :article => ''
    
    add_column :tours, :tourtype_id, :integer
    add_column :tours, :country_id, :integer
    add_column :tours, :link, :string, :comment => 'Ссылка на другой сайт (нужна например для Корпоративные туры в Дании)'
    
    #Дания
    #экскурсионные туры
    Tour.create :tour_name => 'Тур в Данию: Копенгаген – Леголенд / 6 ночей', :tourtype_id => 1, :date_start => '2014-03-12 00:00:00', :date_end => '2014-03-25 00:00:00', :is_daily => 0, :country_id => 3
    Tour.create :tour_name => 'Выходные в Копенгагене / 3 ночи', :tourtype_id => 1, :is_daily => 1, :country_id => 3
    
    #Туры клуба 50+
    Tour.create :tour_name => 'Тур Четыре Северные столицы (ND-6) Клуб 50+', :tourtype_id => 2, :date_start => '2014-03-19 00:00:00', :date_end => '2014-03-20 00:00:00', :is_daily => 0, :country_id => 3

    #Авиатуры по Скандинавии
    Tour.create :tour_name => 'Тур Норвежские фьорды + Копенгаген / 7 дней (AND-7)', :tourtype_id => 3, :date_start => '2014-03-19 00:00:00', :date_end => '2014-03-26 00:00:00', :is_daily => 0, :country_id => 3
    Tour.create :tour_name => 'Тур Норвежские фьорды + Копенгаген / 9 дней (AND-9)', :tourtype_id => 3, :date_start => '2014-03-19 00:00:00', :date_end => '2014-03-28 00:00:00', :is_daily => 0, :country_id => 3
    Tour.create :tour_name => 'Тур Норвежские фьорды + Копенгаген / 11 дней (AND-11)', :tourtype_id => 3, :date_start => '2014-03-19 00:00:00', :date_end => '2014-03-30 00:00:00', :is_daily => 0, :country_id => 3
    
    #Автобусные туры по Скандинавии с круизами на паромах - Лето 2014
    Tour.create :tour_name => 'Тур Финляндия – Швеция – Норвегия – Дания / 13 дней (ND-13)', :tourtype_id => 4, :date_start => '2014-03-10 00:00:00', :date_end => '2014-03-23 00:00:00', :is_daily => 0, :country_id => 3
    Tour.create :tour_name => 'Тур Финляндия – Швеция – Норвегия – Дания / 11 дней (ND-11)', :tourtype_id => 4, :date_start => '2014-03-10 00:00:00', :date_end => '2014-03-21 00:00:00', :is_daily => 0, :country_id => 3
    Tour.create :tour_name => 'Тур Финляндия – Швеция – Норвегия – Дания / 10 дней (ND-10)', :tourtype_id => 4, :date_start => '2014-03-10 00:00:00', :date_end => '2014-03-20 00:00:00', :is_daily => 0, :country_id => 3
    Tour.create :tour_name => 'Тур Финляндия – Швеция – Норвегия – Дания / 9 дней (ND-9)', :tourtype_id => 4, :date_start => '2014-03-10 00:00:00', :date_end => '2014-03-19 00:00:00', :is_daily => 0, :country_id => 3
    Tour.create :tour_name => 'Тур Финляндия – Швеция – Норвегия – Дания / 7 дней (ND-7)', :tourtype_id => 4, :date_start => '2014-03-10 00:00:00', :date_end => '2014-03-17 00:00:00', :is_daily => 0, :country_id => 3
    Tour.create :tour_name => 'Тур Финляндия – Швеция – Норвегия – Дания / 5 дней (ND-5)', :tourtype_id => 4, :date_start => '2014-03-10 00:00:00', :date_end => '2014-03-15 00:00:00', :is_daily => 0, :country_id => 3
    Tour.create :tour_name => 'Тур Финляндия – Швеция – Дания / 5 дней (ND-5)', :tourtype_id => 4, :date_start => '2014-03-10 00:00:00', :date_end => '2014-03-15 00:00:00', :is_daily => 0, :country_id => 3
    Tour.create :tour_name => 'Тур Финляндия – Швеция – Дания – Норвегия / 6 дней (ND-6)', :tourtype_id => 4, :date_start => '2014-03-10 00:00:00', :date_end => '2014-03-16 00:00:00', :is_daily => 0, :country_id => 3
    
    #Индивидуальные туры в парки развлечений
    Tour.create :tour_name => 'Тур в Данию: Парк развлечений "Lalandia Billund"', :tourtype_id => 5, :is_daily => 1, :country_id => 3
    Tour.create :tour_name => 'Тур в Данию: Парк развлечений "Lalandia Rodby"', :tourtype_id => 5, :is_daily => 1, :country_id => 3
    
    #Корпоративные туры
    Tour.create :tour_name => 'Корпоративный туризм', :tourtype_id => 9, :link => 'http://micevents.ru', :country_id => 3
    
    #################################################################################################################
    #Россия
    #Туры по городам золотого кольца
    Tour.create :tour_name => 'Тур "Ростов Великий - Ярославль - Кострома - Переславль-Залесский + терем Снегурочки" (2 дня/1 ночь)', :tourtype_id => 6, :date_start => '2014-03-12 00:00:00', :date_end => '2014-03-15 00:00:00', :is_daily => 0, :country_id => 1
    Tour.create :tour_name => 'Тур "Владимир - Боголюбово - Суздаль + фольклорная программа + интерактивный музей «Бабуся Ягуся»" (2 дня/1 ночь)', :tourtype_id => 6, :date_start => '2014-03-12 00:00:00', :date_end => '2014-03-15 00:00:00', :is_daily => 0, :country_id => 1
    #Туры в Санкт-Петербург
    Tour.create :tour_name => 'Тур "Выходные в Санкт-Петербурге 2 дня / 1 ночь"', :tourtype_id => 7, :date_start => '2014-03-12 00:00:00', :date_end => '2014-03-15 00:00:00', :is_daily => 0, :country_id => 1
    Tour.create :tour_name => 'Тур "Петербург от 2-х до 7-ми дней"', :tourtype_id => 7,  :is_daily => 1, :country_id => 1
    #Туры в Тверскую область, Псков и Великий Новгород
    Tour.create :tour_name => 'Тур "В гости к Гадюке Васильевне" (3 дня/2 ночи)', :tourtype_id => 8, :date_start => '2014-03-12 00:00:00', :date_end => '2014-03-17 00:00:00', :is_daily => 0, :country_id => 1
    #Корпоративные туры
    Tour.create :tour_name => 'Корпоративный туризм', :link => 'http://micevents.ru', :tourtype_id => 9, :country_id => 1
    
    #################################################################################################################
    #Украина
    #экскурсионные туры
    Tour.create :tour_name => 'Тур "Майские праздники в Одессе" (от 3-х до 5-ти дней)', :tourtype_id => 1, :date_start => '2014-03-12 00:00:00', :country_id => 2
    Tour.create :tour_name => 'Тур в Одессу (от 2-х до 7-ми дней)', :tourtype_id => 1, :date_start => '2014-03-12 00:00:00', :country_id => 2
    
    #Праздничные туры
    Tour.create :tour_name => 'Тур "Майские праздники в Киеве" (от 3 до 5 дней)', :tourtype_id => 10, :date_start => '2014-03-12 00:00:00', :country_id => 2
    #Корпоративные туры
    Tour.create :tour_name => 'Корпоративный туризм', :link => 'http://micevents.ru', :tourtype_id => 9, :country_id => 2
  end

  def self.down
    remove_column :tours, :tourtype_id
    remove_column :tours, :link
    remove_column :tours, :country_id
    Country.delete_all
    Tour.delete_all
  end
end
