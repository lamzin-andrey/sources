class CreateTours < ActiveRecord::Migration
  def self.up
    create_table :tours do |t|
      t.column :tour_name, :string
      t.column :date_start, :string
      t.column :date_end, :string
      t.column :is_daily, :integer, :default => 0
      t.column :description, :text
      t.column :page_title, :text
      t.timestamps
    end
  end

  def self.down
    drop_table :tours
  end
end
