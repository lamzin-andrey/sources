class ReplaceFieldUsers < ActiveRecord::Migration
  def self.up
    remove_column :users, :users
    add_column :users, :login, :string
    #change_column :users, :users, :login, :string
  end

  def self.down
    #replace_column :users, :login, :users, :string
    remove_column :users, :login
    add_column :users, :users, :string
  end
end
