class UpdateTitles < ActiveRecord::Migration
  def self.up
    Book.update 1, :title => 'Руслан и Людимила'
    Book.update 2, :title => 'Евгений Онегин'
    Book.update 3, :title => 'Повести Белкина'
    Book.update 4, :title => 'Мцыри'
    Book.update 5, :title => 'Бородино'
    Book.update 6, :title => 'Герой нашего времени'
  end

  def self.down
    Book.update_all("title = ''")
  end
end
