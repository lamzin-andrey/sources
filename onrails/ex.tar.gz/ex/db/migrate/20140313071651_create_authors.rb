class CreateAuthors < ActiveRecord::Migration
  def self.up
    create_table :authors do |t|
      t.column :name, :string
      t.column :surname, :string
      t.column :fathname, :string
      t.column :codename, :string
      t.column :url_tail, :string
      t.timestamps
    end
  end

  def self.down
    drop_table :authors
  end
end
