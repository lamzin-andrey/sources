class CreateAdminAuthors < ActiveRecord::Migration
  def self.up
    create_table :admin_authors do |t|
      t.string :name
      t.string :surname
      t.string :fathname
      t.string :codename
      t.string :urltail
      t.text :article

      t.timestamps
    end
  end

  def self.down
    drop_table :admin_authors
  end
end
