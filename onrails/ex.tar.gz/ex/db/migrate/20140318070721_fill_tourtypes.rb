class FillTourtypes < ActiveRecord::Migration
  def self.up
    Tourtype.create :tourtype_display_text => 'Экскурсионные туры'
    Tourtype.create :tourtype_display_text => 'Туры клуба 50+'
    Tourtype.create :tourtype_display_text => 'Авиатуры по Скандинавии'
    Tourtype.create :tourtype_display_text => 'Автобусные туры по Скандинавии с круизами на паромах - Лето 2014'
    Tourtype.create :tourtype_display_text => 'Индивидуальные туры в парки развлечений'    
    Tourtype.create :tourtype_display_text => 'Туры по городам золотого кольца'
    Tourtype.create :tourtype_display_text => 'Туры в Санкт-Петербург'
    Tourtype.create :tourtype_display_text => 'Туры в Тверскую область, Псков и Великий Новгород'    
    Tourtype.create :tourtype_display_text => 'Корпоративные туры'
    Tourtype.create :tourtype_display_text => 'Праздничные туры'
  end

  def self.down
    Tourtype.delete_all
  end
end
