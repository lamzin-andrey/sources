class Admin::Tourtype < ActiveRecord::Base
  validates_presence_of :tourtype_display_text
  validates_uniqueness_of :tourtype_display_text
  has_many :tours
end
