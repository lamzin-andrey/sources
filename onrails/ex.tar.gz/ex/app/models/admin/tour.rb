class Admin::Tour < ActiveRecord::Base
  validates_presence_of :tour_name
  validates_presence_of :date_start
  validates_presence_of :date_end
  
  protected
  def validate
     if (date_start!= nil && date_end != nil && DateTime.parse(date_start.to_s) >= DateTime.parse(date_end.to_s) )
       errors.add_to_base :bad_date_error
     end
  end
end