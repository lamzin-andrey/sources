class Admin::Author < ActiveRecord::Base
end
