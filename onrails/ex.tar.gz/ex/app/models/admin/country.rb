class Admin::Country < ActiveRecord::Base
  validates_presence_of :country_name
  validates_presence_of :country_code
  validates_presence_of :url_tail
  
end
