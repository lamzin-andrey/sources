class User < ActiveRecord::Base
  validates_presence_of :login
  validates_uniqueness_of :login
  attr_accessor :password_confirmation
  validates_confirmation_of :password
  
  def self.authenticate(name, pwd)
    user = User.find_by_login(name)
    if user
      exp_pwd = self.enc_pass(pwd, user.salt)
      if exp_pwd != user.hashed_password
        user = nill
      end
    end
    user
  end
  
  def validate
    errors.add_to_base 'Пароль не введен' if hashed_password.blank?
   end
   
   
   def password
     @password
   end
   
   def password=(pwd)
     @password = pwd
     create_salt
     self.hashed_password = User.enc_pass(self.password, self.salt)
   end
   
   private
   
   def create_salt
     self.salt = self.object_id.to_s + rand.to_s
   end
   
   def self.enc_pass(pwd, salt)
     str = pwd + 'fdnajkfdhfjfh' + salt
     Digest::SHA1.hexdigest(str)
   end
end
