class Country < ActiveRecord::Base
  has_many :tours
end
