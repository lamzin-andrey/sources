class Tour < ActiveRecord::Base
  belongs_to :country
  belongs_to :tourtype
end
