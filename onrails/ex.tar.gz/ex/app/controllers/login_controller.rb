class LoginController < ApplicationController
  layout 'adminmaster'
  def add_user
	#is_auth
    @user = User.new params[:user]
    if request.post? and @user.save
      flash.now[:notice] = 'User registred'
      @user = User.new 
    end
  end

  def login
    session[:user_id] = nil
    if request.post?
      user = User.authenticate(params[:users], params[:password])
      if user
        session[:user_id] = user.id
        redirect_to session[:referrer] ? session[:referrer] : '/admin/countries'
      else
        flash[:notice] = t(:invalid_password)
      end
    end
  end

  def logout
  end

  def index
  end

  def delete_user
  end

  def list_users
  end

end
