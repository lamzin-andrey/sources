class Admin::CountriesController < ApplicationController
  before_filter :is_auth
  layout 'adminmaster'
  
  # GET /admin_countries
  # GET /admin_countries.xml
  def index
    @admin_countries = Admin::Country.all
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @admin_countries }
    end
  end

  # GET /admin_countries/1
  # GET /admin_countries/1.xml
  def show
    @country = Admin::Country.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @country }
    end
  end

  # GET /admin_countries/new
  # GET /admin_countries/new.xml
  def new
    @country = Admin::Country.new

    respond_to do |format|
      format.js
      format.html # new.html.erb
      format.xml  { render :xml => @country }
    end
  end

  # GET /admin_countries/1/edit
  def edit
    @country = Admin::Country.find(params[:id])
  end

  # POST /admin_countries
  # POST /admin_countries.xml
  def create
    @country = Admin::Country.new(params[:admin_country])
    params[:admin_country][:country_code].downcase!

    respond_to do |format|
      if @country.save
        format.js {@countries = Admin::Country.all}
        format.html { redirect_to(@country, :notice => 'Admin::Country was successfully created.') }
        format.xml  { render :xml => @country, :status => :created, :location => @country }
      else
        format.js   { @countries = Admin::Country.all @errs = @country.errors}
        format.html { render :action => "new" }
        format.xml  { render :xml => @country.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /admin_countries/1
  # PUT /admin_countries/1.xml
  def update
    @country = Admin::Country.find(params[:id])
    params[:admin_country][:country_code].downcase!
    respond_to do |format|
      if @country.update_attributes(params[:admin_country])
        format.js
        format.html { redirect_to(@country, :notice => 'Admin::Country was successfully updated.') }
        format.xml  { head :ok }
      else
        format.js   { @countries = Admin::Country.all @errs = @country.errors}
        format.html { render :action => "edit" }
        format.xml  { render :xml => @country.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /admin_countries/1
  # DELETE /admin_countries/1.xml
  def destroy
    @country = Admin::Country.find(params[:id])
    begin
      @country.destroy
      respond_to do |format|
        format.html { redirect_to(admin_countries_url) }
        format.xml  { head :ok }
      end
    rescue
      respond_to do |format|
        format.html { render :action => "has_child_tours" }
        format.xml  { head :fail }
      end
    end
    
  end
  # GET /admin_countries/1/terminate
  def terminate
	@country = Admin::Country.find(params[:id])
  end
  
  # POST /admin_tourtypes/terminate_all
  def terminate_all
    ids = params[:ids]
    begin
      Admin::Country.delete(ids.values)
      respond_to do |format|
        format.html { redirect_to("/admin/countries") }
        format.xml  { head :ok }
      end
    rescue
      respond_to do |format|
        format.html { render :action => "has_child_tours" }
        format.xml  { head :fail }
      end
    end
  end
  
  
end
