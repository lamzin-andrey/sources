class Admin::TourtypesController < ApplicationController
  before_filter :is_auth
  layout 'adminmaster'
  
  # POST /admin_tourtypes/ajaxnew
  # POST /admin_tourtypes/ajaxnew.xml
  def ajaxnew
    #добавляем тип тура и обновляем данные в вписке
    @tourtype = Admin::Tourtype.new(params[:admin_tourtype])
    
    respond_to do |format|
      if (@tourtype.save)
        #Для вьюшки tourtypeslist
        @tour = Admin::Tour.new
        @tour.tourtype_id = 0
        @tourtypes = Admin::Tourtype.all
        format.js
        format.html # new.html.erb
        #format.xml  { render :xml => @tour }
      else
        # надеюсь, достаточно здесь просто переписать акшин, ну и создать все вьюшки
        format.js { render :action => "error_add_tourtype" }
        format.html { render :action => "error_add_tourtype" }
        format.xml  { render :xml => @tour.errors, :status => :unprocessable_entity }
      end
    end
  end
  
  # POST /admin_tourtypes/new
  # POST /admin_tourtypes/new.xml
  def new
    #добавляем тип тура и обновляем данные в списке
    @tourtype = Admin::Tourtype.new(params[:admin_tourtype])
    
    respond_to do |format|
      if (@tourtype.save)
        @tourtypes = Admin::Tourtype.all
        format.js
        format.html # new.html.erb
        #format.xml  { render :xml => @tour }
      else
        format.js { render :action => "error_add_tourtype" }
        format.html { render :action => "error_add_tourtype" }
        format.xml  { render :xml => @tour.errors, :status => :unprocessable_entity }
      end
    end
  end
  
  # POST /admin_tourtypes/update
  # POST /admin_tourtypes/update.xml
  def update
    #обновляем тип тура и обновляем данные в списке
    @tourtype = Admin::Tourtype.find(params[:admin_tourtype][:id])
    
    respond_to do |format|
      if @tourtype.update_attributes( params[:admin_tourtype])
        @tourtypes = Admin::Tourtype.all
        format.js { render :action => 'new' }
        format.html # new.html.erb
        #format.xml  { render :xml => @tour }
      else        # надеюсь, достаточно здесь просто переписать акшин, ну и создать все вьюшки
        format.js { render :action => "error_add_tourtype" }
        format.html { render :action => "error_add_tourtype" }
        format.xml  { render :xml => @tour.errors, :status => :unprocessable_entity }
      end
    end
  end
  
  
  # GET /admin_tourtypes
  # GET /admin_tourtypess.xml
  def index
    @admin_tourtypes = Admin::Tourtype.all
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @admin_tourtypes }
    end
  end
  
  # DELETE /admin_tourtypes/1
  # DELETE /admin_tourtypes/1.xml
  def destroy
    @tourtype = Admin::Tourtype.find(params[:id])
    @tourtype.destroy

    respond_to do |format|
      format.html { redirect_to("/admin/tourtypes") }
      format.xml  { head :ok }
    end
  end
  
  # GET /admin_tourtypes/1/terminate
  def terminate
    @tourtype = Admin::Tourtype.find(params[:id])
  end
  
  # POST /admin_tourtypes/terminate_all
  def terminate_all
    ids = params[:ids]
    Admin::Tourtype.delete(ids.values)
    respond_to do |format|
      format.html { redirect_to("/admin/tourtypes") }
      format.xml  { head :ok }
    end
  end
  
end
