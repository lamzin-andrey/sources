class Admin::ToursController < ApplicationController
  before_filter :is_auth
  layout 'adminmaster'
  
  # GET /admin_tours
  # GET /admin_tours.xml
  def index
    render :status => 404, :layout =>"errorpage"
  end
  
  def country
    @cid = params[:id]
    @admin_tours = Admin::Tour.find_all_by_country_id(@cid)
    @country = Admin::Country.find(@cid)
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @admin_tours }
    end
  end

  # GET /admin_tours/1
  # GET /admin_tours/1.xml
  def show
    @tour = Admin::Tour.find(params[:id])
    @cid = @tour.country_id

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @tour }
    end
  end

  # GET /admin_tours/new
  # GET /admin_tours/new.xml
  def new
    @tour = Admin::Tour.new
    @tour.country_id = params[:id]
    @tourtypes = Admin::Tourtype.all
    respond_to do |format|
      format.js
      format.html # new.html.erb
      format.xml  { render :xml => @tour }
    end
  end

  # GET /admin_tours/1/edit
  def edit
    @tour = Admin::Tour.find(params[:id])
    @tourtypes = Admin::Tourtype.all
  end

  # POST /admin_tours
  # POST /admin_tours.xml
  def create
    @tour = Admin::Tour.new(params[:admin_tour])

    respond_to do |format|
      if @tour.save
        format.js {@tours = Admin::Tour.find_all_by_country_id(params[:admin_tour][:country_id])}
        format.html { redirect_to(@tour, :notice => 'Admin::our was successfully created.') }
        format.xml  { render :xml => @tour, :status => :created, :location => @tour }
      else
        format.js do
          @tours = Admin::Tour.find_all_by_country_id(params[:admin_tour][:country_id])
          @errs = @tour.errors
        end
        format.html { render :action => "new" }
        format.xml  { render :xml => @tour.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /admin_tours/1
  # PUT /admin_tours/1.xml
  def update
    @tour = Admin::Tour.find(params[:id])

    respond_to do |format|
      if @tour.update_attributes(params[:admin_tour])
        format.js
        format.html { redirect_to(@tour, :notice => 'Admin::tour was successfully updated.') }
        format.xml  { head :ok }
      else
        format.js do
          @tours = Admin::Tour.find_all_by_country_id(params[:admin_tour][:country_id])
          @errs = @tour.errors
        end
        format.html { render :action => "edit" }
        format.xml  { render :xml => @tour.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /admin_tours/1
  # DELETE /admin_tours/1.xml
  def destroy
    @tour = Admin::Tour.find(params[:id])
    cid = @tour.country_id
    @tour.destroy

    respond_to do |format|
      format.html { redirect_to("/admin/tours/country/#{cid}") }
      format.xml  { head :ok }
    end
  end
  # GET /admin_tours/1/terminate
  def terminate
	  @tour = Admin::Tour.find(params[:id])
  end
  
  # POST /admin_tours/terminate_all
  def terminate_all
    ids = params[:ids]
    #ids . each do |key, val|
    Admin::Tour.delete(ids.values)
    
    respond_to do |format|
      format.html { redirect_to("/admin/tours/country/#{params[:id]}") }
      format.xml  { head :ok }
    end
  end
end
