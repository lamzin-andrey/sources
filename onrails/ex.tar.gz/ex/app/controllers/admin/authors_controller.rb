class Admin::AuthorsController < ApplicationController
  before_filter :is_auth
  layout 'myfrontpage'
  # GET /admin_authors
  # GET /admin_authors.xml
  def index
    @admin_authors = Admin::Author.all

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @admin_authors }
    end
  end

  # GET /admin_authors/1
  # GET /admin_authors/1.xml
  def show
    @author = Admin::Author.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @author }
    end
  end

  # GET /admin_authors/new
  # GET /admin_authors/new.xml
  def new
    @author = Admin::Author.new

    respond_to do |format|
      format.js
      format.html # new.html.erb
      format.xml  { render :xml => @author }
    end
  end

  # GET /admin_authors/1/edit
  def edit
    @author = Admin::Author.find(params[:id])
    #if @author
        #format.html { redirect_to(@author, :notice => 'Admin::Author was successfully created.') }
        #@format.js #{ render :xml => @author, :status => :created, :location => @author }
    #end
  end

  # POST /admin_authors
  # POST /admin_authors.xml
  def create
    @author = Admin::Author.new(params[:admin_author])

    respond_to do |format|
      if @author.save
        format.js {@authors = Admin::Author.all}
        format.html { redirect_to(@author, :notice => 'Admin::Author was successfully created.') }
        format.xml  { render :xml => @author, :status => :created, :location => @author }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @author.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /admin_authors/1
  # PUT /admin_authors/1.xml
  def update
    @author = Admin::Author.find(params[:id])

    respond_to do |format|
      if @author.update_attributes(params[:admin_author])
        format.js
        format.html { redirect_to(@author, :notice => 'Admin::Author was successfully updated.') }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @author.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /admin_authors/1
  # DELETE /admin_authors/1.xml
  def destroy
    @author = Admin::Author.find(params[:id])
    @author.destroy

    respond_to do |format|
      format.html { redirect_to(admin_authors_url) }
      format.xml  { head :ok }
    end
  end
end
