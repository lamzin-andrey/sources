class MyfrontpageController < ApplicationController
  def request_processor
    @country  = Country.find_by_country_code params[:word1]
    @page_title = @country.page_title
    if (@country == nil)
      render :status => 404, :layout => 'errorpage', :action=>'err404'
    else
      @tour_list = Tour.find_all_by_country_id(@country)
      @countries_list = Country.all  
    end
  end
  
  def index
    @countries_list = Country.all
  end 
  
  def err404
    render :status => 404, :layout => 'errorpage'
  end
end
