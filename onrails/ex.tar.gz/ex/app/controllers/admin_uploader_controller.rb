class AdminUploaderController < ApplicationController
  before_filter :is_auth
  # ALL
  def upload_image
    tmp_file = params[:userfile]
    File.open(Rails.root.join('public/images', tmp_file.original_filename), 'wb') do |dest_file|
       dest_file.write(tmp_file.read)
    end
    @filename = '/images/' +  tmp_file.original_filename
  end

end
