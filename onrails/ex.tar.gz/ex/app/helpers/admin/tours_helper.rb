module Admin::ToursHelper
  def calendar_view (obj, field)
    a = obj.to_s.sub(/<(\w+\:\:\w+).*>/, '\1').downcase.sub('#', '').split('::')
    prefix = a.join('_')
    
    date = ''
    if (obj[field].to_s.strip.size > 0)
      date = obj[field].to_s(:ru_datetime)
    end
    s = "<div class=\"calendar_input\">
        <input type=\"text\" value=\"#{date}\" size=\"30\" name=\"#{prefix}[#{field}]\" id=\"#{prefix}_#{field}\" readonly=\"readonly\">
      <div class=\"dateField\" id=\"#{prefix}_#{field}_button\"><img src=\"/images/calendar.png\"></div>
      <div class=\"both\"></div>
      </div>"
    s
  end
  
  def custom_selectbox (prefix, data, name, selected_id)
    s = "<select id=\"#{prefix}_#{name}\" name=\"#{prefix}[#{name}]\">"
    data.each do |r|
      v = ''
      if (r.id == selected_id)
        v = ' selected="selected" '
      end
      s += "<option value=\"#{r.id}\"#{v}>#{r.tourtype_display_text}</option>"
    end 
    s += "</select>"
  end
  
  class Tmp24
    def initialize 
    end
    
  end
  
  def admin_tours_helper_tmp24_path(s)
      '/'
    end
  
end

