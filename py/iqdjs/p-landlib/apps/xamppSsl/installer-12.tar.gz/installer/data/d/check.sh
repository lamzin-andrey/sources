#!/bin/bash
xdg-user-dir DOCUMENTS > /home/xubuntu/Downloads/installer/data/d/documents.txt
