#!/bin/bash
cp /home/xubuntu/Downloads/installer/data/fastxamppssl.desktop /home/xubuntu/.config/autostart/fastxamppssl.desktop
cp /home/xubuntu/Downloads/installer/data/fastxamppssl.desktop /home/xubuntu/.local/share/applications/fastxamppssl.desktop
pkexec /home/xubuntu/Downloads/installer/data/d/unpack.sh > /home/xubuntu/Downloads/installer/data/d/out.txt 2>&1