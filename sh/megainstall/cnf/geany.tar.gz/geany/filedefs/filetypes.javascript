[build-menu]
FT_00_LB=8
FT_00_CM=php /home/andrey/hdata/programs/my/bash/geany/index.php %d/%f %p
FT_00_WD=/home/andrey/hdata/programs/my/bash/geany
