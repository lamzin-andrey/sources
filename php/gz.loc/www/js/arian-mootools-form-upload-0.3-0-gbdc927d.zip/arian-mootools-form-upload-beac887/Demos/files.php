<?php

echo '<pre>';

print_r($_FILES);

print_r($_POST);

